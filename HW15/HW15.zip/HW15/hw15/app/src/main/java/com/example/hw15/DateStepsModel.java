package com.example.hw15;

public class DateStepsModel {
    public String mDate;
    public int mStepCount;
}
