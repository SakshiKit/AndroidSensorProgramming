package com.example.hw14;

public class DateStepsModel {
    public String mDate;
    public int mStepCount;
}
